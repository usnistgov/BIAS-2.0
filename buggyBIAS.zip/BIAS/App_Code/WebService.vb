﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System
Imports System.IO
Imports gov.nist.itl.iad.ig.bias.ref


' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService( _
   Namespace:="gov.nist.itl.iad.ig.bias.ref", _
   Description:="BIAS Tester Service")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class WebService
    Implements BIAS_v1

    <WebMethod()> _
    Public Function AddSubjectToGallery(AddSubjectToGalleryRequest As AddSubjectToGalleryRequest) As AddSubjectToGalleryResponsePackage Implements BIAS_v1.AddSubjectToGallery
        Dim galleryResponse As New AddSubjectToGalleryResponsePackage()
        Return galleryResponse
    End Function

    <WebMethod()> _
    Public Function CheckQuality(CheckQualityRequest As CheckQualityRequest) As CheckQualityResponsePackage Implements BIAS_v1.CheckQuality
        Dim qualityResponse As New CheckQualityResponsePackage()
        Return qualityResponse
    End Function

    <WebMethod()> _
    Public Function ClassifyBiometricData(ClassifyBiometricDataRequest As ClassifyBiometricDataRequest) As ClassifyBiometricDataResponsePackage Implements BIAS_v1.ClassifyBiometricData
        Dim classifyBioDataReponse As New ClassifyBiometricDataResponsePackage()
        Return classifyBioDataReponse
    End Function

    <WebMethod()> _
    Public Function CreateSubject(CreateSubjectRequest As CreateSubjectRequest) As CreateSubjectResponsePackage Implements BIAS_v1.CreateSubject
        Dim createSubjectResponse As New CreateSubjectResponsePackage()
        Return createSubjectResponse
    End Function

    <WebMethod()> _
    Public Function DeleteBiographicData(DeleteBiographicDataRequest As DeleteBiographicDataRequest) As DeleteBiographicDataResponsePackage Implements BIAS_v1.DeleteBiographicData
        Dim deleteBiogDataResponse As New DeleteBiographicDataResponsePackage()
        Return deleteBiogDataResponse
    End Function

    <WebMethod()> _
    Public Function DeleteBiometricData(DeleteBiometricDataRequest As DeleteBiometricDataRequest) As DeleteBiometricDataResponsePackage Implements BIAS_v1.DeleteBiometricData
        Dim deleteBiomDataResponse As New DeleteBiometricDataResponsePackage()
        Return deleteBiomDataResponse
    End Function

    <WebMethod()> _
    Public Function DeleteSubject(DeleteSubjectRequest As DeleteSubjectRequest) As DeleteSubjectResponsePackage Implements BIAS_v1.DeleteSubject
        Dim deleteSubjectResponse As New DeleteSubjectResponsePackage()
        Return deleteSubjectResponse
    End Function

    <WebMethod()> _
    Public Function DeleteSubjectFromGallery(DeleteSubjectFromGalleryRequest As DeleteSubjectFromGalleryRequest) As DeleteSubjectFromGalleryResponsePackage Implements BIAS_v1.DeleteSubjectFromGallery
        Dim deleteSubjectGalleryResponse As New DeleteSubjectFromGalleryResponsePackage()
        Return deleteSubjectGalleryResponse
    End Function

    Public Function Enroll(EnrollRequest As EnrollRequest) As EnrollResponsePackage Implements BIAS_v1.Enroll
        Dim enrollResponse As New EnrollResponsePackage()
        Return enrollResponse
    End Function

    Public Function GetEnrollResults(GetEnrollResultsRequest As GetEnrollResultsRequest) As GetEnrollResultsResponsePackage Implements BIAS_v1.GetEnrollResults
        Dim enrollResultsResponse As New GetEnrollResultsResponsePackage()
        Return enrollResultsResponse
    End Function

    Public Function GetIdentifyResults(GetIdentifyResultsRequest As GetIdentifyResultsRequest) As GetIdentifyResultsResponsePackage Implements BIAS_v1.GetIdentifyResults
        Dim identityResultsResponse As New GetIdentifyResultsResponsePackage()
        Return identityResultsResponse
    End Function

    <WebMethod()> _
    Public Function GetIdentifySubjectResults(GetIdentifySubjectResultsRequest As GetIdentifySubjectResultsRequest) As GetIdentifySubjectResultsResponsePackage Implements BIAS_v1.GetIdentifySubjectResults
        Dim identitySubjectResultsResponse As New GetIdentifySubjectResultsResponsePackage()
        Return identitySubjectResultsResponse
    End Function

    Public Function GetVerifyResults(GetVerifyResultsRequest As GetVerifyResultsRequest) As GetVerifyResultsResponsePackage Implements BIAS_v1.GetVerifyResults
        Dim verifyResultsResponse As New GetVerifyResultsResponsePackage()
        Return verifyResultsResponse
    End Function

    Public Function Identify(IdentifyRequest As IdentifyRequest) As IdentifyResponsePackage Implements BIAS_v1.Identify
        Dim identifyResponse As New IdentifyResponsePackage()
        Return identifyResponse
    End Function

    <WebMethod()> _
    Public Function IdentifySubject(IdentifySubjectRequest As IdentifySubjectRequest) As IdentifySubjectResponsePackage Implements BIAS_v1.IdentifySubject
        Dim identifySubjectResponse As New IdentifySubjectResponsePackage()
        Return identifySubjectResponse
    End Function

    <WebMethod()> _
    Public Function ListBiographicData(ListBiographicDataRequest As ListBiographicDataRequest) As ListBiographicDataResponsePackage Implements BIAS_v1.ListBiographicData
        Dim listBiogDataResponse As New ListBiographicDataResponsePackage()
        Return listBiogDataResponse
    End Function

    <WebMethod()> _
    Public Function ListBiometricData(ListBiometricDataRequest As ListBiometricDataRequest) As ListBiometricDataResponsePackage Implements BIAS_v1.ListBiometricData
        Dim listBiomDataResponse As New ListBiometricDataResponsePackage()
        Return listBiomDataResponse
    End Function

    <WebMethod()> _
    Public Function PerformFusion(PerformFusionRequest As PerformFusionRequest) As PerformFusionResponsePackage Implements BIAS_v1.PerformFusion
        Dim performFusionResponse As New PerformFusionResponsePackage()
        Return performFusionResponse
    End Function

    <WebMethod()> _
    Public Function QueryCapabilities(QueryCapabilitiesRequest As QueryCapabilitiesRequest) As QueryCapabilitiesResponsePackage Implements BIAS_v1.QueryCapabilities
        Dim queryCapabilitiesResponse As New QueryCapabilitiesResponsePackage()
        Return queryCapabilitiesResponse
    End Function

    <WebMethod()> _
    Public Function RetrieveBiographicData(RetrieveBiographicDataRequest As RetrieveBiographicDataRequest) As RetrieveBiographicDataResponsePackage Implements BIAS_v1.RetrieveBiographicData
        Dim retrieveBiogDataResponse As New RetrieveBiographicDataResponsePackage()
        Return retrieveBiogDataResponse
    End Function

    <WebMethod()> _
    Public Function RetrieveBiometricData(RetrieveBiometricDataRequest As RetrieveBiometricDataRequest) As RetrieveBiometricDataResponsePackage Implements BIAS_v1.RetrieveBiometricData
        Dim retrieveBiomDataResponse As New RetrieveBiometricDataResponsePackage()
        Return retrieveBiomDataResponse
    End Function

    Public Function RetrieveData(RetrieveDataRequest As RetrieveDataRequest) As RetrieveDataResponsePackage Implements BIAS_v1.RetrieveData
        Dim retrieveDataResponse As New RetrieveDataResponsePackage()
        Return retrieveDataResponse
    End Function

    <WebMethod()> _
    Public Function SetBiographicData(SetBiographicDataRequest As SetBiographicDataRequest) As SetBiographicDataResponsePackage Implements BIAS_v1.SetBiographicData
        Dim setBiogDataResponse As New SetBiographicDataResponsePackage()
        Return setBiogDataResponse
    End Function

    <WebMethod()> _
    Public Function SetBiometricData(SetBiometricDataRequest As SetBiometricDataRequest) As SetBiometricDataResponsePackage Implements BIAS_v1.SetBiometricData
        Dim setBiomDataResponse As New SetBiometricDataResponsePackage()
        Return setBiomDataResponse
    End Function

    <WebMethod()> _
    Public Function TransformBiometricData(TransformBiometricDataRequest As TransformBiometricDataRequest) As TransformBiometricDataResponsePackage Implements BIAS_v1.TransformBiometricData
        Dim transformBiomDataResponse As New TransformBiometricDataResponsePackage()
        Return transformBiomDataResponse
    End Function

    <WebMethod()> _
    Public Function UpdateBiographicData(UpdateBiographicDataRequest As UpdateBiographicDataRequest) As UpdateBiographicDataResponsePackage Implements BIAS_v1.UpdateBiographicData
        Dim updateBiogDataResponse As New UpdateBiographicDataResponsePackage()
        Return updateBiogDataResponse
    End Function

    <WebMethod()> _
    Public Function UpdateBiometricData(UpdateBiometricDataRequest As UpdateBiometricDataRequest) As UpdateBiometricDataResponsePackage Implements BIAS_v1.UpdateBiometricData
        Dim updateBiomDataResponse As New UpdateBiometricDataResponsePackage()
        Return updateBiomDataResponse
    End Function


    Public Function Verify(VerifyRequest As VerifyRequest) As VerifyResponsePackage Implements BIAS_v1.Verify
        Dim verifyResponse As New VerifyResponsePackage()
        Return verifyResponse
    End Function

    <WebMethod()> _
    Public Function VerifySubject(VerifySubjectRequest As VerifySubjectRequest) As VerifySubjectResponsePackage Implements BIAS_v1.VerifySubject
        Dim verifySubjectResponse As New VerifySubjectResponsePackage()
        Return verifySubjectResponse
    End Function
End Class